angular.module('todoaf',[])
.config(function () {

});



$.afui.ready(function(){
    angular.bootstrap(document, ['todoaf']);
});