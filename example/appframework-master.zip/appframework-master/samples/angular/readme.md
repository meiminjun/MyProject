#sample

This sample is to show basic usage of Angular and App Framework UI.  This does not go into more advanced features, such as page routing/navigation.   The key takeway is delaying the loading of Angular until App Framework UI has been dispatched for loading the "partials" in App Framework UI.  This also shows using a directive for the "longTap" event App Framework UI dispatches.